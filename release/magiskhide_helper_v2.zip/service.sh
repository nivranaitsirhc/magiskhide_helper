magiskhide --status | grep 'not' || (sleep 10;magiskhide --disable;sleep 5;magiskhide --enable;)
