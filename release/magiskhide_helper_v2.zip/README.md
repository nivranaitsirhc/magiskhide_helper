# MagiskHide Helper
For devices that died in vain waiting for proc_monitor to detect zygote.<br><br>
*Restarts magiskhide before the boot process completes. <br>
*Targeted for devices with backported namespace patch (unsupported kernel version).<br>
