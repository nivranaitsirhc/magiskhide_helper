#!/bin/sh
[ $MAGISK_VER_CODE < 20000 ] && abort "Magisk version not supported. Please update Magisk to v20 or higher!"

